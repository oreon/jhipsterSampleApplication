# React Router v4 sample code
[Click for preview](https://rawgit.com/thatisuday/react-router-learning/master/dist/index.html)

## Medium blog with explaination
[https://medium.com/@thatisuday/basics-of-react-router-v4-336d274fd9e0](https://medium.com/@thatisuday/basics-of-react-router-v4-336d274fd9e0)
