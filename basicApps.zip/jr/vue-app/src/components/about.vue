<template>
  <div class="about">
    <h1>Welcome new user</h1>
    <p>
      It's a Pleasure to have you here
    </p>
  </div>
</template>

<script>
  export default {
    name: 'About'
  }
</script>
