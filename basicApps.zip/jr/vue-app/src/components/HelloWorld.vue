<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
    <h5> Tell us a bit about yourself </h5>
    <form id="myform" @submit.prevent="submitForm">
      <div class="form-group">
        <label for="name">Name</label>
        <input type="text" placeholder="Name" name="name" v-model="name"  id="name"  v-validate="'required|alpha'">
        <span v-if="errors.has('name')">
        {{ errors.first('name') }}
       </span>
      </div>

      <div class="form-group">
        <label for="movie">Favorite Movie</label>
        <select name="movie" id="movie" v-model="movie">
          <option>Star Wars</option>
          <option>Vanilla Sky</option>
          <option>Atomic Blonde</option>
        </select>
      </div>

      <p>
        <input type="submit" value="Submit">
      </p>

    </form>
  </div>
</template>

<script>
  import router from '../router'


  export default {
    name: 'Hello',
    data () {
      return {
        msg: 'Welcome to Alberta Blue Cross'
      }
    },
    methods: {
      submitForm() {
        this.$validator.validateAll().then(res=>{
          if(res) {
            router.push({ name: "About" });
          } else {
            alert('Please correct all errors!')
          }
        })
      }
    }
  }
</script>
