import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  heroForm: FormGroup; // <--- heroForm is of type FormGroup

  ngOnInit(){
    this.createForm();
  }

  constructor(private fb: FormBuilder, private router: Router,) { // <--- inject FormBuilder
    
  }

  createForm() {
    this.heroForm = this.fb.group({
      name: ['', Validators.required ],
      age:['', Validators.required ],
    });
  }

  onSubmit(){
    if(this.heroForm.valid)
      this.router.navigate(['/home'],{ queryParams: {name:this.heroForm.value['name']}})
  }


}
